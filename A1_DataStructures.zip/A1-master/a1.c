#include "a1.h"
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "get_bits.h"

unsigned char checksum( char *string ){
int val;
    val = 0;
char string1[1000];

    strcpy(string1,string);

    for(int i = 0; string[i]; i++){

        if (isupper(string1[i])){
            string1[i] = tolower(string1[i]);
        }

    }

    for(int i = 0; string[i]; i++){
        if(islower(string1[i])){
            val+=string1[i]-97;

        }

    }

return val % 26;
}


void caesar(char* string, int rshift)
{
    for (int i = 0; i < strlen(string); i++)
    {
        if ('A' <= string[i] && string[i] <= 'Z')
            string[i] = (char)(65 + (string[i] - 65 + rshift) % 26);
    }
}



void char2bits( char c, unsigned char bits[8] ) {

    unsigned char rv = 0;

    int i = 0;
    for(i = 0; i<8; i++){

       rv = get_bits8(i,i + 1,&c)+'0';

       bits[i] = rv;


    }




}

void bits2str( int bitno, unsigned char *bits, char *bitstr ){


    int i;
    for(i = 0; i < bitno; i++){
        bitstr[i] = bits[i];


    }
    bitstr[bitno] = '\0';

}

void ushort2bits( unsigned short s, unsigned char bits[16] ) {

    unsigned char as = 0;

    int i = 0;

    for (i = 0; i < 16; i++){

        as = get_bits16(i,i+1,&s)+'0';

        bits[i] = as;


    }

}

void short2bits(short s, unsigned char bits[16] ){

    unsigned char as = 0;

    int i = 0;

    for (i = 0; i < 16; i++){

        as = get_bits16(i,i+1,&s)+'0';

        bits[i] = as;


    }

}
short bits2short( char *bits ){
    int i;
    unsigned char twoscomstr[16];
    int twospower = 0;
    short result = 0;
    if(bits[0]=='0'){
      for(i =15; i>=0 ;i--){
          if(bits[i] =='1'){

            result = result + powertwo(twospower);
          }
          twospower ++;
      }
      return result;
    }
    unsigned char onescompliment[16];
    unsigned short onesval = 0;
    for(i=0; i<16; i++){
      if (bits[i] == '1'){
          onescompliment[i] = '0';
      } else {
        onescompliment[i] = '1';
      }
    }
    twospower = 1;
    if(onescompliment[15]=='1'){
      onesval = 1;
    }
    for(i =14; i>=0 ;i--){
      if(onescompliment[i]=='1'){
        onesval = onesval + powertwo(twospower);
      }
      twospower++;
    }
    onesval++;
    ushort2bits(onesval,twoscomstr);

    twospower = 0;
    for(i =15; i>=0 ;i--){
        if(twoscomstr[i] =='1'){

          result = result + powertwo(twospower);

        }
        twospower ++;
    }

    return result * -1;
}

short powertwo(int index){
  short value = 1;
  int i;
  if(index ==0){

    return 1;
  }

  for(i = 0;i<index;i++){

    value = value * 2;

  }
  return value;


}
void printshort (unsigned char * str){

  int i;
    for(i = 0; i<16; i++) {

      printf("%c",str[i]);
    }
    printf("\n");
}
