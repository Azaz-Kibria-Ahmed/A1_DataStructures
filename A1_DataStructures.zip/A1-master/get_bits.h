unsigned char get_bits8( unsigned char from,
                        unsigned char to,
                        void *data );

unsigned short get_bits16( unsigned char from,
                        unsigned char to,
                        void *data );

unsigned int get_bits32( unsigned char from,
                        unsigned char to,
                        void *data );

unsigned long get_bits64( unsigned char from,
                        unsigned char to,
                        void *data );
